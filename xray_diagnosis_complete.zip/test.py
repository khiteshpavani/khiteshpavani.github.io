######################################################################################################
#Author: Krishna Hitesh Pavani
#Description: Testing code for X-ray Diagnosis using Neural Network
#Neural Networks Tested : Densenet169, Densenet121, InceptionV3, SE Densenet121, SE InceptionV3
######################################################################################################


import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import os
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import os
from glob import glob
import matplotlib.pyplot as plt
from keras.preprocessing.image import ImageDataGenerator
from keras.models import Sequential, Model
from keras.applications.densenet import DenseNet121
from keras.applications.vgg16 import VGG16, preprocess_input
from keras.preprocessing.image import ImageDataGenerator,load_img, img_to_array
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D, Dense, Dropout, Input, Flatten, SeparableConv2D
from keras.layers import GlobalMaxPooling2D
from keras.layers import GlobalAveragePooling2D, Dense, Dropout, Flatten
from keras.layers.normalization import BatchNormalization
from keras.layers.merge import Concatenate
from keras.models import Model
from keras.optimizers import Adam, SGD, RMSprop
from keras.callbacks import ModelCheckpoint, Callback, EarlyStopping
from keras.utils import to_categorical

from keras.callbacks import ModelCheckpoint, LearningRateScheduler, EarlyStopping, ReduceLROnPlateau
import h5py
from my_models import predict_using_densenet169_model
from sklearn.metrics import roc_auc_score

#Read Data input file containing image label information
all_xray_df = pd.read_csv('./data/Data_Entry_2017.csv')

                   
all_image_paths = {os.path.basename(x): x for x in 
                   glob(os.path.join('.', 'data', 'images', '*.png'))}
print('Scans found:', len(all_image_paths), ', Total Headers', all_xray_df.shape[0])
all_xray_df['path'] = all_xray_df['Image Index'].map(all_image_paths.get)


all_xray_df['Finding Labels'] = all_xray_df['Finding Labels'].map(lambda x: x.replace('No Finding', ''))
from itertools import chain
all_labels = np.unique(list(chain(*all_xray_df['Finding Labels'].map(lambda x: x.split('|')).tolist())))
all_labels = [x for x in all_labels if len(x)>0]
print('All Labels ({}): {}'.format(len(all_labels), all_labels))
for c_label in all_labels:
    if len(c_label)>1: # leave out empty labels
        all_xray_df[c_label] = all_xray_df['Finding Labels'].map(lambda finding: 1.0 if c_label in finding else 0)
      
# Using the test_list_smallsubset.txt file for testing dataset
test_list = open("./data/NIH_Dataset/test_list_smallsubset.txt").read().splitlines()
df_testing = all_xray_df[all_xray_df['Image Index'].isin(test_list)]
print("Length of Testing Dataset:",len(df_testing))


# Adding each disease label as vector to data frame for both training and testing.
#df_train_val['disease_vec'] = df_train_val.apply(lambda x: [x[all_labels].values], 1).map(lambda x: x[0])
df_testing['disease_vec'] = df_testing.apply(lambda x: [x[all_labels].values], 1).map(lambda x: x[0])



IMG_SIZE = (224, 224)
test_datagenerator = ImageDataGenerator(rescale=1./255)


core_idg = ImageDataGenerator(samplewise_center=True, 
                              samplewise_std_normalization=True, 
                              horizontal_flip = True, 
                              vertical_flip = False, 
                              height_shift_range= 0.05, 
                              width_shift_range=0.1, 
                              rotation_range=5, 
                              shear_range = 0.1,
                              fill_mode = 'reflect',
                              zoom_range=0.15)
							  

							
def flow_from_dataframe(img_data_gen, in_df, path_col, y_col, **dflow_args):
    base_dir = os.path.dirname(in_df[path_col].values[0])
    print('## Ignore next message from keras, values are replaced anyways')
    df_gen = img_data_gen.flow_from_directory(base_dir, 
                                     class_mode = 'sparse',
                                    **dflow_args)
    df_gen.filenames = in_df[path_col].values
    df_gen.classes = np.stack(in_df[y_col].values)
    df_gen.samples = in_df.shape[0]
    df_gen.n = in_df.shape[0]
    df_gen._set_index_array()
    df_gen.directory = '' # since we have the full path
    print('Reinserting dataframe: {} images'.format(in_df.shape[0]))
    return df_gen
                            
test_gen = flow_from_dataframe(test_datagenerator, 
                               df_testing, 
                             path_col = 'path',
							 shuffle=False,
                            y_col = 'disease_vec', 
                            target_size = IMG_SIZE,
                             color_mode = 'rgb',
                            batch_size = 256)

                           
#Loading the saved Model
from keras.models import load_model
#model = load_model('my_saved_model.h5')

model = predict_using_densenet169_model()
model.load_weights(r"./weights.h5")
model.summary()


#Predictions

test_X, test_Y = next(flow_from_dataframe(test_datagenerator, 
                               df_testing, 
                             path_col = 'path',
                            y_col = 'disease_vec', 
                            target_size = IMG_SIZE,
                             color_mode = 'rgb',
                            batch_size = 64)) # one big batch

pred_Y = model.predict(test_X, batch_size = 32, verbose = True)

# look at how often the algorithm predicts certain diagnoses 
for c_label, p_count, t_count in zip(all_labels, 
                                     100*np.mean(pred_Y,0), 
                                     100*np.mean(test_Y,0)):
    print('%s: Dx: %2.2f%%, PDx: %2.2f%%' % (c_label, t_count, p_count))
	
from sklearn.metrics import roc_curve, auc
fig, c_ax = plt.subplots(1,1, figsize = (9, 9))
for (idx, c_label) in enumerate(all_labels):
    fpr, tpr, thresholds = roc_curve(test_Y[:,idx].astype(int), pred_Y[:,idx])
    c_ax.plot(fpr, tpr, label = '%s (AUC:%0.2f)'  % (c_label, auc(fpr, tpr)))
c_ax.legend()
c_ax.set_xlabel('False Positive Rate')
c_ax.set_ylabel('True Positive Rate')
fig.savefig('AUROC_curve.png')


sickest_idx = np.argsort(np.sum(test_Y, 1)<1)
fig, m_axs = plt.subplots(4, 2, figsize = (16, 32))

print("Predictions for the small sample set\n")
for (idx, c_ax) in zip(sickest_idx, m_axs.flatten()):
    c_ax.imshow(test_X[idx, :,:,0], cmap = 'bone')
    stat_str = [n_class[:6] for n_class, n_score in zip(all_labels, 
                                                                  test_Y[idx]) 
                             if n_score>0.5]
    pred_str = ['%s:%2.0f%%' % (n_class[:4], p_score*100)  for n_class, n_score, p_score in zip(all_labels, 
                                                                  test_Y[idx], pred_Y[idx]) 
                             if (n_score>0.5) or (p_score>0.5)]
    c_ax.set_title('Dx: '+', '.join(stat_str)+'\nPDx: '+', '.join(pred_str))
    c_ax.axis('off')
fig.savefig('trained_img_predictions.png')

print("AUROC Scores for available labels in the sample set \n")
aurocs = []
for i in range(len(all_labels)):
    try:
        score = roc_auc_score(test_Y[:,i].astype(int), pred_Y[:,i])
        aurocs.append(score)
        print(all_labels[i],":",score)
		
    except ValueError:
        score = 0	

print("Please check files AUROC_curve.png and trained_img_predictions.png")
	
	

