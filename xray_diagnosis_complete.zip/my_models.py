

from keras.models import Sequential, Model
from keras.applications.densenet import DenseNet121
from keras.applications.vgg16 import VGG16, preprocess_input
from keras.preprocessing.image import ImageDataGenerator,load_img, img_to_array
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D, Dense, Dropout, Input, Flatten, SeparableConv2D
from keras.layers import GlobalMaxPooling2D
from keras.layers import GlobalAveragePooling2D, Dense, Dropout, Flatten
from keras.layers.normalization import BatchNormalization
from keras.layers.merge import Concatenate
from keras.models import Model
from keras.optimizers import Adam, SGD, RMSprop
from keras.callbacks import ModelCheckpoint, Callback, EarlyStopping
from keras.utils import to_categorical
from keras.models import load_model


#Import all necessary models (Densenet, Inception, SE Densenet)
from keras.applications.densenet import DenseNet121
from keras.applications.densenet import DenseNet169
from keras.applications.inception_v3 import InceptionV3
from se_densenet import SEDenseNetImageNet121
from se_inception_v3 import SEInceptionV3



#Building the Model

# Function for DenseNet121 
def predict_using_densenet121_model():
	
    img_input = Input(shape=(224,224,3))
    base_model = DenseNet121(
    include_top=False,
	input_tensor=img_input,
    input_shape=(224,224,3),
    pooling="avg")
    x = base_model.output
    predictions = Dense(14, activation="sigmoid", name="predictions")(x)
    model = Model(inputs=img_input, outputs=predictions)
    return model
	
# Function for DenseNet169
def predict_using_densenet169_model():
	
    img_input = Input(shape=(224,224,3))
    base_model = DenseNet169(
    include_top=False,
	input_tensor=img_input,
    input_shape=(224,224,3),
    pooling="avg")
    x = base_model.output
    predictions = Dense(14, activation="sigmoid", name="predictions")(x)
    model = Model(inputs=img_input, outputs=predictions)
    return model

# Function for InceptionV3
def predict_using_InceptionV3_model():
	
    img_input = Input(shape=(224,224,3))
    base_model = InceptionV3(
    include_top=False,
	input_tensor=img_input,
    input_shape=(224,224,3),
    pooling="avg")
    x = base_model.output
    predictions = Dense(14, activation="sigmoid", name="predictions")(x)
    model = Model(inputs=img_input, outputs=predictions)
    return model
# Function for SE DenseNet121
def se_densenet121_model():
    img_input = Input(shape=(224,224,3))
    base_model = SEDenseNetImageNet121(input_shape=(224, 224, 3),
                          bottleneck=True,
                          reduction=0.5,
                          dropout_rate=0.0,
                          weight_decay=1e-4,
                          include_top=False,
                          weights="imagenet",
                          input_tensor=img_input,
                          classes=1000,
                          activation='softmax')
    x = base_model.output
    predictions = Dense(14, activation="sigmoid", name="predictions")(x)
    model = Model(inputs=img_input, outputs=predictions)
    return model
# Function for SE InceptionV3
def se_inceptionv3_model():
    img_input = Input(shape=(224,224,3))
    base_model = SEDenseNetImageNet121(input_shape=(224, 224, 3),
                          bottleneck=True,
                          reduction=0.5,
                          dropout_rate=0.0,
                          weight_decay=1e-4,
                          include_top=False,
                          weights="imagenet",
                          input_tensor=img_input,
                          classes=1000,
                          activation='softmax')
    x = base_model.output
    predictions = Dense(14, activation="sigmoid", name="predictions")(x)
    model = Model(inputs=img_input, outputs=predictions)
    return model
	
a = se_inceptionv3_model()
a.summary()
