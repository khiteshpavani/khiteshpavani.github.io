README
1) Download the NIH Chest X-ray Dataset from Kaggle into the data (presently empty) folder provided.
2) For running training Run "python train.py"
3) For running testing make sure the model ("my_saved_model.h5") is present in the folder and run "python test.py"
4)  For running the GUI Standalone the following files are required: 
    a)diagnose_xray
	b)True_Labels.csv
	c)weights.h5
	d)x_rays folder containing random x-rays
	
5) Considering the large dataset the parameters have been minimized in the files. The actual testing and training were done for complete dataset and also for longer epochs. Code from the following github repo was used for running some of the tests (https://github.com/brucechou1983/CheXNet-Keras).