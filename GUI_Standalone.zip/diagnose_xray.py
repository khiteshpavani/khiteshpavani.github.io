######################################################################################################
#Author: Krishna Hitesh Pavani
#Description: GUI code for X-ray Diagnosis using Neural Network
#Neural Network Used : Densenet169
######################################################################################################

# Importing all modules
import tkinter
import cv2
from tkinter import *
from tkinter.filedialog import askopenfilename
from PIL import Image, ImageTk
from keras.models import load_model
import numpy
import pandas as pd
import keras  
from keras.models import Sequential, Model
from keras.applications.densenet import DenseNet169
from keras.preprocessing.image import ImageDataGenerator,load_img, img_to_array
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D, Dense, Dropout, Input, Flatten, SeparableConv2D
from keras.layers import GlobalMaxPooling2D
from keras.layers import GlobalAveragePooling2D, Dense, Dropout, Flatten
from keras.layers.normalization import BatchNormalization
from keras.layers.merge import Concatenate
from keras.models import Model
from keras.optimizers import Adam, SGD, RMSprop
from keras.callbacks import ModelCheckpoint, Callback, EarlyStopping
from keras.utils import to_categorical
import os

#instantiating necessary objects
top = Tk()
top.title = 'X-Ray Diagnosis'
top.geometry('512x450')

# Instruction
l1=Label(top,text='Load the X-ray Image and Click on Diagnose Button')
l1.grid(row=0)

# Function to show image
e = StringVar()
all_labels = ['Atelectasis', 'Cardiomegaly', 'Consolidation', 'Edema', 'Effusion', 'Emphysema', 'Fibrosis', 'Hernia', 'Infiltration', 'Mass', 'Nodule', 'Pleural_Thickening', 'Pneumonia', 'Pneumothorax']	   

disease_thresholds = [0.19362465, 0.07700258, 0.5, 0.5, 0.3401143, 0.5, 0.5, 0.5, 0.39875817, 0.08521137, 0.14014415, 0.5, 0.02213187, 0.08226113]

#True Labels are in csv file
true_labels = pd.read_csv("True_Labels.csv")


	   
#Function for DenseNet169
def predict_using_densenet169_model():
	
    img_input = Input(shape=(224,224,3))
    base_model = DenseNet169(
    include_top=False,
	input_tensor=img_input,
    input_shape=(224,224,3),
    pooling="avg")
    x = base_model.output
    predictions = Dense(14, activation="sigmoid", name="predictions")(x)
    model = Model(inputs=img_input, outputs=predictions)
    return model
	
def showImg():
    global File
    File = askopenfilename(title='Open X-Ray') 
    e.set(File)
	
    load = Image.open(e.get())
	#process image for display
    w, h = load.size
    load = load.resize((342,342))
    imgfile = ImageTk.PhotoImage(load)
    canvas.image = imgfile  # reference of your image
    canvas.create_image(3,2,anchor='nw',image=imgfile)
	
 
	

# Diagnose function for getting prediction from the models
def diagnose() :
	#xray = Image.open(e.get())
	#Preprocess image		
    inputimage = cv2.imread(e.get())
	# Preprocess image data to feed to predictor
    xray = cv2.resize(inputimage, (224,224))
    if xray.shape[2] == 1:
        xray = numpy.dstack([xray, xray, xray])
    else:
        xray = cv2.cvtColor(xray, cv2.COLOR_BGR2RGB)
    xray_array = numpy.array(xray)
    xray = xray.astype('float32')
    xray /= 255.0
    xray = numpy.expand_dims(xray, axis=0)

    # True labels 
    global list_of_diseases
	#Checking for true labels based on File Name
    df_temp = true_labels.loc[true_labels['Image Index'] == str(os.path.basename(File))]
    #print(df_temp)
    df_temp = df_temp[all_labels]
    diseases = df_temp.columns[(df_temp == 1).all()]
    list_of_diseases = diseases.tolist()
    print(list_of_diseases)	
	
    #test_data = numpy.array(test_data)
    #print("Total number of test examples: ", test_data.shape)	
    
    predictions = model.predict(xray)
    prediction_max = numpy.argmax(predictions, axis=1)
    prediction_max_value = numpy.amax(predictions)
	
    [prediction_result1] = prediction_max.tolist()
	
    [list_of_predictions] = predictions.tolist()
    print("prediction list\n", list_of_predictions)
    output_text1 = " Predicted Diagnosis \n"
    disease_predicted = 0
	
	#iterating over each class to check prediction
    for i in range(14):
        if (float(list_of_predictions[i]) > float(disease_thresholds[i])):
            #print(all_labels[i], "is present\n")
            output_text1+=str(all_labels[i])+':'
            #output_text1+=':'
            output_text1+=str(round(list_of_predictions[i]*100,2))+'%\n'
            disease_predicted = 1
    #print(output_text1)
    i = 0
    if (disease_predicted == 0):
	    output_text1+="No Diseases \n"
		
    output_text2 = "True Diagnosis: \n"
    if (len(list_of_diseases) == 0):
        output_text2 += "No Finding\n"
    else:
        output_text2 += str(list_of_diseases)+'\n'

    #output_text = "     Diseases: Probabilities\nPneumonia is %s\nProbability: %s \n\n          result1\n Prediction is %s" % (prediction_display, prediction_probability,accuracy_display)	
    result1.delete(0.0, tkinter.END)
    result2.delete(0.0, tkinter.END)
    result1.insert('insert', output_text1)
    #result1.insert('end',output_text2)
    #result1.tag_config("end", font="yellow")
    result2.insert('insert',output_text2)
    result1.update()
    result2.update()
	

model = predict_using_densenet169_model()
model.load_weights(r".\weights.h5")
model.summary()

# Button to upload image
predict_button = Button(top, text ='Load X-ray',bg='light grey', command = showImg, relief=RAISED)
predict_button.grid(row=1, column=0)

# Button for Diagnosis
diagnose_button = Button(top, text ='Diagnose', bg ='green', command = diagnose, relief=RAISED)
diagnose_button.grid(row=1, column=1)

# Canvas that will show the x-ray.
canvas = Canvas(top, width=345, height=345, bd=1, bg='white')
canvas.grid(row=2, column=0)

# Displaying result1
result1=Text(top,bd=1, bg='light grey', fg='Red', width=19,height=9,font='Fixdsys -14')
result1.grid(row=2, column=1)

result2=Text(top,bd=1, bg='light grey', fg='Green', width=19,height=7,font='Fixdsys -14')
result2.grid(row=3, column=1)

top.mainloop()